export default [
  { name: "KITCHEN", count: 5 },
  { name: "LIVING ROOM 1", count: 3 },
  { name: "KITCHEN WINDOW", count: 2 },
  { name: "BALCONY", count: 3 },
  { name: "MARBLE STAIRS", count: 2 },
  { name: "MICROWAVE", count: 2 },
  { name: "WATER DISPENSER", count: 2 },
  { name: "KITCHEN SINK AND FLOOR", count: 2 },
  { name: "TRASHBIN AREA", count: 3 },
  { name: "GREEN STAIRS", count: 5 },
  { name: "STAIRS GOING TO 3RD FLOOR", count: 3 },
  { name: "LAUNDRY AREA", count: 5 },
  { name: "BIG WINDOW", count: 2 },
  { name: "VACANT ROOM", count: 2 },
  { name: "LIVING ROOM 2", count: 2 },
  { name: "SMOKING AREA", count: 2 }
];
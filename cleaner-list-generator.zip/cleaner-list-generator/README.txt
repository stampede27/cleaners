==== Cleaner List Generator ====

1. Install Node.js from https://nodejs.org (LTS version)
2. Open a terminal/command prompt in this folder
3. Run:
   npm install
   npm run dev

Your cleaner list generator will open at http://localhost:5173